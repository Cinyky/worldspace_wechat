// pages/pt/group/details.js
// var api = require('../../../api.js');
// var utils = require('../../../utils.js');
var server = require('../../../utils/server');
var utils = require('../../../utils.js');
var app = getApp();
console.log(app)
Page({

  /**
   * 页面的初始数据
   */
  data: {
    groupFail: 0,
    show_attr_picker: false,
    form: {
      number: 1,
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options)
    // app.pageOnLoad(this);
    console.log("options=>" + JSON.stringify(options));
    var scene = decodeURIComponent(options.scene);
    if (scene != undefined) {
      // console.log("scene string=>" + scene);
      var scene_obj = utils.scene_decode(scene);
      // console.log("scene obj=>" + JSON.stringify(scene_obj));
      if (scene_obj.pint_id) {
        options.pint_id = scene_obj.pint_id;
      }
    }
    this.setData({
      pint_id: options.pint_id,
    });
    var app = getApp();
    var openId = app.globalData.openid;
    var that = this;
    app.getOpenId(function () {

      var openId = app.globalData.openid;
      server.getJSON("/User/validateOpenid", { openid: openId }, function (res) {
        // console.log(1);
        // console.log(res.data.data.user_id);
        // console.log(options);
        // console.log(2);
        if (res.data.code == 200) {

          if (res.data.data.mobile > 0) {
            app.globalData.is_phone = 0;
          }
          options.user_id = res.data.data.user_id;
          app.globalData.userInfo = res.data.data;
          app.globalData.login = true;
          console.log(123321323131231)
          console.log(options)
          console.log(3142134234234234)
          that.getInfo(options);
        }
        else {
          if (res.data.code == '400') {

            app.redirectTo("../../login/login");

          }
          // });
        }
      });

    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // app.pageOnShow(this);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (options) {
    var page = this;
    // var user_info = wx.getStorageSync("user_info");
    var path = '/pages/pint/group/details?pint_id=' + page.data.pint_id;
    return {
      title: "快来" + page.data.goods.pt_price + "元拼  " + page.data.goods.goods_name,
      path: path,
      //   imageUrl: page.data.goods.cover_pic,
      success: function (res) {
        console.log(path)
        console.log(res)
      }
    }
  },
  /**
   * 获取信息
   */
  getInfo: function (e) {
    console.log(123)
    console.log(e)
    console.log(456)
    var pint_id = e.pint_id;
    var page = this;
    // wx.showLoading({
    //     title: "正在加载",
    //     mask: true,
    // });
    console.log(getApp().globalData.userInfo.user_id)
    var user_id = getApp().globalData.userInfo.user_id
    server.getJSON('/Pint/getPintInfo/pint_id/' + pint_id + '/user_id/' + user_id, function (res) {
      // if (res.code == 0) {
      if (res.data.groupFail == 0) {
        page.countDownRun(res.data.limit_time_ms);
      }
      // page.countDownRun(res.data.limit_time_ms);
      // var reduce_price = (res.data.goods.original_price - res.data.goods.price).toFixed(2);
      // var reduce_price = 50;
      console.log(213321312312312);
      console.log(res.data);
      page.setData({
        goods: res.data.goods,
        groupList: res.data.groupList,
        surplus: res.data.surplus,
        limit_time_ms: res.data.limit_time_ms,
        goods_list: res.data.goodsList,
        group_fail: res.data.groupFail,
        // oid: res.data.oid,
        in_group: res.data.inGroup,
        // attr_group_list: res.data.attr_group_list,
        // group_rule_id: res.data.groupRuleId,
        // reduce_price: reduce_price < 0 ? 0 : reduce_price,
      });
      // } else {
      //   wx.showModal({
      //     title: '提示',
      //     content: res.msg,
      //     showCancel: false,
      //     success: function (res) {
      //       if (res.confirm) {
      //         wx.redirectTo({
      //           url: '/pages/pint/index/index'
      //         });
      //       }
      //     }
      //   });
      // }





    });
  },
  /**
* 执行倒计时
*/
  countDownRun: function (limit_time_ms) {
    var page = this;
    setInterval(function () {
      var leftTime = (new Date(limit_time_ms[0], limit_time_ms[1] - 1, limit_time_ms[2], limit_time_ms[3], limit_time_ms[4], limit_time_ms[5])) - (new Date()); //计算剩余的毫秒数 
      var days = parseInt(leftTime / 1000 / 60 / 60 / 24, 10); //计算剩余的天数 
      var hours = parseInt(leftTime / 1000 / 60 / 60 % 24, 10); //计算剩余的小时 
      var minutes = parseInt(leftTime / 1000 / 60 % 60, 10);//计算剩余的分钟 
      var seconds = parseInt(leftTime / 1000 % 60, 10);//计算剩余的秒数 

      days = page.checkTime(days);
      hours = page.checkTime(hours);
      minutes = page.checkTime(minutes);
      seconds = page.checkTime(seconds);
      page.setData({
        limit_time: {
          days: days,
          hours: hours,
          mins: minutes,
          secs: seconds,
        },
      });
    }, 1000);
  },
  /**
   * 时间补0
   */
  checkTime: function (i) { //将0-9的数字前面加上0，例1变为01 
    i = i > 0 ? i : 0;
    if (i < 10) {
      i = "0" + i;
    }
    return i;
  },
  /**
   * 返回首页
   */
  goToHome: function () {
    wx.redirectTo({
      url: '/pages/pint/index/index'
    })
  },
  /**
   * 前往商品详情
   */
  goToGoodsDetails: function (e) {
    var page = this;
    wx.redirectTo({
      url: '/pages/pint/details/details?gid=' + page.data.goods.goods_id,
    });
  },
  /**
* 隐藏规格选择框
*/
  hideAttrPicker: function () {
    var page = this;
    page.setData({
      show_attr_picker: false,
    });
  },
  /**
   * 显示规格选择框
   */
  showAttrPicker: function () {
    var page = this;
    page.setData({
      show_attr_picker: true,
    });
  },
  attrClick: function (e) {
    var page = this;
    var attr_group_id = e.target.dataset.groupId;
    var attr_id = e.target.dataset.id;
    var attr_group_list = page.data.attr_group_list;
    for (var i in attr_group_list) {
      if (attr_group_list[i].attr_group_id != attr_group_id)
        continue;
      for (var j in attr_group_list[i].attr_list) {
        if (attr_group_list[i].attr_list[j].attr_id == attr_id) {
          attr_group_list[i].attr_list[j].checked = true;
        } else {
          attr_group_list[i].attr_list[j].checked = false;
        }
      }
    }
    page.setData({
      attr_group_list: attr_group_list,
    });

    var check_attr_list = [];
    var check_all = true;
    for (var i in attr_group_list) {
      var group_checked = false;
      for (var j in attr_group_list[i].attr_list) {
        if (attr_group_list[i].attr_list[j].checked) {
          check_attr_list.push(attr_group_list[i].attr_list[j].attr_id);
          group_checked = true;
          break;
        }
      }
      if (!group_checked) {
        check_all = false;
        break;
      }
    }
    if (!check_all)
      return;
    wx.showLoading({
      title: "正在加载",
      mask: true,
    });
    app.request({
      url: api.group.goods_attr_info,
      data: {
        goods_id: page.data.goods.id,
        attr_list: JSON.stringify(check_attr_list),
      },
      success: function (res) {
        wx.hideLoading();
        if (res.code == 0) {
          var goods = page.data.goods;
          goods.price = res.data.price;
          goods.num = res.data.num;
          goods.attr_pic = res.data.pic;
          page.setData({
            goods: goods,
          });
        }
      }
    });
  },
  /**
  * 参团
  */
  buyNow: function () {
    var a = this;
    if (!a.data.show_attr_picker) {
      return a.setData({
        show_attr_picker: !0
      }), !0;
    }
    var goods = this.data.goods;
    var spec = ""
    // if (goods.goods.goods_spec_list != null)
    //   for (var i = 0; i < goods.goods.goods_spec_list.length; i++) {

    //     for (var j = 0; j < goods.goods.goods_spec_list[i].length; j++) {
    //       if (goods.goods.goods_spec_list[i][j].isClick == 1) {
    //         if (spec == "")
    //           spec = goods.goods.goods_spec_list[i][j].item_id
    //         else
    //           spec = spec + "_" + goods.goods.goods_spec_list[i][j].item_id
    //       }
    //     }
    //   }
    var app = getApp()
    var that = this;
    console.log(that)
    var goods_id = that.data.goods.goods_id;
    var pint_id = that.data.pint_id;
    // console.log(pint_id)
    // var goods_spec = spec;
    var goods_spec = '';
    var session_id = app.globalData.openid//that.data.goods.goods.spec_goods_price
    var goods_num = that.data.form.number;;

    var user_id = "0"
    if (app.globalData.login)
      user_id = app.globalData.userInfo.user_id
    //立即购买先清空购物车
    server.getJSON('/Cart/emptyCart', { session_id: session_id, user_id: user_id });

    server.getJSON('/Cart/addCart', { goods_id: goods_id, goods_spec: goods_spec, session_id: session_id, goods_num: goods_num, user_id: user_id, is_pint: '1', pint_id: pint_id }, function (res) {
      that.setData({
        show_attr_picker: !1
      })
      if (res.data.status == 1) {
        // console.log(status)
        wx.navigateTo({
          url: '../ordersubmit/index?cartIds=' + goods_id + '&amount=' + goods_num * goods.pt_price
        });
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'error',
          duration: 2000
        });
      }
    });
    return;
  },
  /**
   * 订单提交
   */
  submit: function (type) {
    var page = this;
    console.log(page.data.show_attr_picker);
    if (!page.data.show_attr_picker) {
      page.setData({
        show_attr_picker: true,
      });
      return true;
    }

    if (page.data.form.number > page.data.goods.num) {
      wx.showToast({
        title: "商品库存不足，请选择其它规格或数量",
        image: "/images/icon-warning.png",
      });
      return true;
    }
    var attr_group_list = page.data.attr_group_list;
    var checked_attr_list = [];
    for (var i in attr_group_list) {
      var attr = false;
      for (var j in attr_group_list[i].attr_list) {
        if (attr_group_list[i].attr_list[j].checked) {
          attr = {
            attr_id: attr_group_list[i].attr_list[j].attr_id,
            attr_name: attr_group_list[i].attr_list[j].attr_name,
          };
          break;
        }
      }
      if (!attr) {
        wx.showToast({
          title: "请选择" + attr_group_list[i].attr_group_name,
          image: "/images/icon-warning.png",
        });
        return true;
      } else {
        checked_attr_list.push({
          attr_group_id: attr_group_list[i].attr_group_id,
          attr_group_name: attr_group_list[i].attr_group_name,
          attr_id: attr.attr_id,
          attr_name: attr.attr_name,
        });
      }
    }

    page.setData({
      show_attr_picker: false,
    });
    // console.log(JSON.stringify({
    //     goods_id: page.data.goods.id,
    //     attr: checked_attr_list,
    //     num: page.data.form.number,
    //     type: type,
    // }));return true;
    wx.redirectTo({
      url: "/pages/pint/ordersubmit/ordersubmit?goods_info=" + JSON.stringify({
        goods_id: page.data.goods.id,
        attr: checked_attr_list,
        num: page.data.form.number,
        type: type,
        parent_id: page.data.oid,
        deliver_type: page.data.goods.type
      }),
    });
  },
  numberSub: function () {
    var page = this;
    var num = page.data.form.number;
    if (num <= 1)
      return true;
    num--;
    page.setData({
      form: {
        number: num,
      }
    });
  },
  numberAdd: function () {
    var page = this;
    var num = page.data.form.number;
    num++;
    if (num > page.data.goods.one_buy_limit) {
      wx.showModal({
        title: '提示',
        content: '最多只允许购买' + page.data.goods.one_buy_limit + '件',
        showCancel: false,
      });
      return;
    }
    page.setData({
      form: {
        number: num,
      }
    });
  },
  numberBlur: function (e) {
    var page = this;
    var num = e.detail.value;
    num = parseInt(num);
    if (isNaN(num))
      num = 1;
    if (num <= 0)
      num = 1;
    if (num > page.data.goods.one_buy_limit) {
      wx.showModal({
        title: '提示',
        content: '最多只允许购买' + page.data.goods.one_buy_limit + '件',
        showCancel: false,
      });
      return;
    }
    page.setData({
      form: {
        number: num,
      }
    });
  },
  /**
   * 拼团规则
   */
  goArticle: function (e) {
    wx.navigateTo({
      url: '/pages/topic/topic?id=-1',
    });
  },
  showShareModal: function (e) {
    console.log(e);
    var page = this;
    page.setData({
      share_modal_active: "active",
      no_scroll: true,
    });
  },

  shareModalClose: function () {
    var page = this;
    page.setData({
      share_modal_active: "",
      no_scroll: false,
    });
  },
  getGoodsQrcode: function () {
    var page = this;
    page.setData({
      goods_qrcode_active: "active",
      share_modal_active: "",
    });
    if (page.data.goods_qrcode)
      return true;

    var pint_id = this.data.pint_id;
    var user_id = getApp().globalData.userInfo.user_id;
    server.getJSON('/Goods/pintQrcode', { pint_id: pint_id, user_id: user_id }, function (res) {
        if (res.data.code == 0) {
          page.setData({
            goods_qrcode: res.data.data.pic_url,
          });
        }
        if (res.code == 1) {
          page.goodsQrcodeClose();
          wx.showModal({
            title: "提示",
            content: res.msg,
            showCancel: false,
            success: function (res) {
              if (res.confirm) {

              }
            }
          });
        }
    });
  },
  goodsQrcodeClose: function () {
    var page = this;
    page.setData({
      goods_qrcode_active: "",
      no_scroll: false,
    });
  },

  saveGoodsQrcode: function () {
    var page = this;
    if (!wx.saveImageToPhotosAlbum) {
      // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。',
        showCancel: false,
      });
      return;
    }

    wx.showLoading({
      title: "正在保存图片",
      mask: false,
    });

    wx.downloadFile({
      url: page.data.goods_qrcode,
      success: function (e) {
        wx.showLoading({
          title: "正在保存图片",
          mask: false,
        });
        wx.saveImageToPhotosAlbum({
          filePath: e.tempFilePath,
          success: function () {
            wx.showModal({
              title: '提示',
              content: '商品海报保存成功',
              showCancel: false,
            });
          },
          fail: function (e) {
            wx.showModal({
              title: '图片保存失败',
              content: e.errMsg,
              showCancel: false,
            });
          },
          complete: function (e) {
            console.log(e);
            wx.hideLoading();
          }
        });
      },
      fail: function (e) {
        wx.showModal({
          title: '图片下载失败',
          content: e.errMsg + ";" + page.data.goods_qrcode,
          showCancel: false,
        });
      },
      complete: function (e) {
        console.log(e);
        wx.hideLoading();
      }
    });
  },
  goodsQrcodeClick: function (e) {
    var src = e.currentTarget.dataset.src;
    wx.previewImage({
      urls: [src],
    });
  },
})